package com.water.alkaline.kengen.ui.listener;

import com.water.alkaline.kengen.model.main.Pdf;

public interface OnPdfListener {
    public void onItemClick(int position, Pdf item);
}
