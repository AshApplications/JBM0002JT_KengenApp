package com.water.alkaline.kengen.ui.listener;

import com.water.alkaline.kengen.model.DownloadEntity;

public interface OnDownloadListener {
    public void onItemClick(int position, DownloadEntity entity);
}
