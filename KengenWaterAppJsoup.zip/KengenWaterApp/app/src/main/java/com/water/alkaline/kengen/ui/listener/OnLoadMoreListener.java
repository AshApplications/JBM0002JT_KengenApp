package com.water.alkaline.kengen.ui.listener;

public interface OnLoadMoreListener {
    void onLoadMore();
}