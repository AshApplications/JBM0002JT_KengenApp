package com.water.alkaline.kengen.library;

import android.graphics.Bitmap;

public interface ActionListeners {
    void convertedWithSuccess(Bitmap var1, String var2);

    void convertedWithError(String var1);
}