package com.water.alkaline.kengen.ui.listener;

import com.water.alkaline.kengen.model.main.Channel;

public interface OnChannelListener {
    public void onItemClick(int position, Channel item);
}
