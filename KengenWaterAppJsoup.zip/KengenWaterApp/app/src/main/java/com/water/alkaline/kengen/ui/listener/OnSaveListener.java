package com.water.alkaline.kengen.ui.listener;

import com.water.alkaline.kengen.model.SaveEntity;

public interface OnSaveListener {
    public void onItemClick(int position, SaveEntity item);
}
